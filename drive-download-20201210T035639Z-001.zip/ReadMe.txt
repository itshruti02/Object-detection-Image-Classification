=======================================
Below is the explanation for each file:
=======================================
Local versions are for runing on local machine.

Versions 4 and 5 are the final model on Colab.

project_binbin is an early VGG-16 like model.

Binbin Code + Anderson_s structure is a 128x128 implementation

Trained version of the model can be found at: (model 31, as in generated with Version 3 file)
https://drive.google.com/file/d/1N2doVEUBVplnDoPCbd43jLhzYev6SGxL/view?usp=sharing